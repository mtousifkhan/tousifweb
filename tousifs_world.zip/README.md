
# Tousif's World

A simple, stylish personal blog built with Flask and Tailwind CSS.

## Quick Start (Local)
```bash
pip install -r requirements.txt
python app.py
```
Open http://localhost:5000 in your browser.

## Deploy to Render
1. Sign in to [Render](https://render.com) with your GitHub account.
2. Click **New > Web Service**.
3. Connect the repository (or upload this project).
4. Use the following settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
5. (Optional) Set **Environment Variable** `ADMIN_PASSWORD` to a strong password.
6. Click **Create Web Service**. Render will build and deploy your site and give you a live link.

## Deploy to Replit
1. Go to [Replit](https://replit.com).
2. Click **+ Create Repl** > **Import from GitHub** (or upload the ZIP).
3. Choose **Python** as the language.
4. Add a **Secrets** environment variable `ADMIN_PASSWORD`.
5. Run the repl. Replit will automatically provide a live URL.

## Admin Login
- Navigate to `/admin` on your site.
- Enter the `ADMIN_PASSWORD` to post new articles.

---
Built with ❤️ for Tousif.
