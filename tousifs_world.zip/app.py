
from flask import Flask, render_template, request, redirect, url_for
import sqlite3, os

app = Flask(__name__)
DATABASE = 'database.db'

def init_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS articles
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  title TEXT NOT NULL,
                  content TEXT NOT NULL)''')
    # insert a first article if none exist
    c.execute("SELECT COUNT(*) FROM articles")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO articles (title, content) VALUES (?, ?)",
                  ("My First Step into the Tech World",
"""I’m currently a **first‑year student**, and I’ve chosen **Computer Science** as my major subject. Right now, I’m learning **Python programming**, and I’m enjoying every bit of it.\n\nThis is just the beginning of my journey — but mark my words: **InshaAllah**, you’ll see what I do in the future.\n\nI’m 100% committed to my dream of becoming a **top‑level professional in Cyber Security**. I know it won’t be easy, but I believe in hard work, passion, and the power of learning.\n\nStay connected with *Tousif’s World*, because this is just the first step — and many exciting things are coming ahead!"""))
    conn.commit()
    conn.close()

@app.before_first_request
def setup():
    init_db()

@app.route('/')
def index():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, title FROM articles ORDER BY id DESC")
    posts = c.fetchall()
    conn.close()
    return render_template('index.html', posts=posts)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/article/<int:post_id>')
def article(post_id):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT title, content FROM articles WHERE id=?", (post_id,))
    post = c.fetchone()
    conn.close()
    if post:
        return render_template('article.html', title=post[0], content=post[1])
    return "Article not found", 404

ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        pwd = request.form.get('password')
        if pwd != ADMIN_PASSWORD:
            return render_template('admin.html', error="Incorrect password")
        title = request.form.get('title')
        content = request.form.get('content')
        if title and content:
            conn = sqlite3.connect(DATABASE)
            c = conn.cursor()
            c.execute("INSERT INTO articles (title, content) VALUES (?, ?)", (title, content))
            conn.commit()
            conn.close()
            return redirect(url_for('index'))
        return render_template('admin.html', error="Title and content are required")
    return render_template('admin.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.getenv("PORT", 5000)))
